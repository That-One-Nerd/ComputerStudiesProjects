﻿namespace AirTrajectoryBuilder.ObjectModels;

public enum ResultsFileMode
{
    None,
    TextBest,
    TextAll,
    JsonBest,
    JsonAll,
    BinaryBest,
    BinaryAll
}
