﻿using System.Windows.Forms;

namespace AirTrajectoryBuilder.Forms;

public partial class SweepCancelForm : Form
{
    public SweepCancelForm()
    {
        InitializeComponent();
    }
}
